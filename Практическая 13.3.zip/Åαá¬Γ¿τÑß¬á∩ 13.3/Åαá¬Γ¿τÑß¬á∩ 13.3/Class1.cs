﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Практическая_13._3
{
    internal class Measuring_device
    {
        string Device;
        string Name;
        string Model;
        int W;
        string Color;
        int Price;

        public Measuring_device(string name, string model, int w, string color, string device)
        {
            this.Name = name;
            this.Model = model;
            this.W = w;
            this.Color = color;
            this.Device = device;
        }
        public void Set_price(int model, int w)
        {
            this.Price = 5000 * model * w;
        }
        public void Set_name(string name)
        {
            this.Name = name;
        }
        public void Set_model(string model)
        {
            this.Model = model;
        }
        public void Set_W(int w)
        {
            this.W = w;
        }
        public void Set_color(string color)
        {
            this.Color = color;
        }
        public void Set_price(int price)
        {
            this.Price = price;
        }
        public void Set_device(string device)
        {
            this.Device = device;
        }
        public string Enter_device()
        {
            return this.Device;
        }
        public string Enter_name()
        {
            return this.Name;
        }
        public string Enter_model()
        {
            return this.Model;
        }
        public int Enter_W()
        {
            return this.W;
        }
        public string Enter_color()
        {
            return this.Color;
        }
        public int Enter_price()
        {
            return this.Price;
        }
    }
}
