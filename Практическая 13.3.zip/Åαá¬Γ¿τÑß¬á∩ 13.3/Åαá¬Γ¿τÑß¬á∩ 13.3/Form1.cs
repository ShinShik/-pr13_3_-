﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Практическая_13._3
{
    public partial class Form1 : Form
    {
        private DataGridViewColumn dataGridViewDevice = null;
        private DataGridViewColumn dataGridViewName = null;
        private DataGridViewColumn dataGridViewModel = null;
        private DataGridViewColumn dataGridViewW = null;
        private DataGridViewColumn dataGridViewColor = null;
        private DataGridViewColumn dataGridViewPrice = null;        
        Dictionary<string, Measuring_device> Devices = new Dictionary<string, Measuring_device>();
        List<Measuring_device> Dev = new List<Measuring_device>();


        public Form1()
        {
            InitializeComponent();            
        }

        private void удалитьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            bool t= false;
            DialogResult dialogResult = MessageBox.Show("Вы уверены?", "Нет", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                Devices.Remove(dataGridView1.Rows[dataGridView1.SelectedCells[0].RowIndex].Cells[1].Value.ToString());
                Dev.RemoveAt(dataGridView1.SelectedCells[0].RowIndex);
                dataGridView1.Rows.Clear();
                t = true;                
            }
            else if (dialogResult == DialogResult.No)
            {
                ;
            }
            if (t)
            {
                foreach (Measuring_device s in Dev)
                {
                    DataGridViewRow row = new DataGridViewRow();
                    DataGridViewTextBoxCell cell1 = new DataGridViewTextBoxCell();
                    DataGridViewTextBoxCell cell2 = new DataGridViewTextBoxCell();
                    DataGridViewTextBoxCell cell3 = new DataGridViewTextBoxCell();
                    DataGridViewTextBoxCell cell4 = new DataGridViewTextBoxCell();
                    DataGridViewTextBoxCell cell5 = new DataGridViewTextBoxCell();
                    DataGridViewTextBoxCell cell6 = new DataGridViewTextBoxCell();
                    cell1.Value = s.Enter_device();
                    cell2.Value = s.Enter_name();
                    cell3.Value = s.Enter_model();
                    cell4.Value = s.Enter_W();
                    cell5.Value = s.Enter_color();
                    cell6.Value = s.Enter_price();
                    row.Cells.Add(cell1);
                    row.Cells.Add(cell2);
                    row.Cells.Add(cell3);
                    row.Cells.Add(cell4);
                    row.Cells.Add(cell5);
                    row.Cells.Add(cell6);
                    dataGridView1.Rows.Add(row);
                }
            }
        }

        private void contextMenuStripDell_Opening(object sender, CancelEventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void comboBoxDevice_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBoxModel_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBoxStrong_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void textBoxColor_TextChanged(object sender, EventArgs e)
        {

        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBoxDevice.Text) && 
                !string.IsNullOrEmpty(comboBoxModel.Text) &&
                !string.IsNullOrEmpty(comboBoxStrong.Text) &&
                !string.IsNullOrEmpty(textBoxColor.Text)
                )
            {
                try
                {
                    Measuring_device dev = new Measuring_device(textBoxDevice.Text, comboBoxModel.Text, int.Parse(comboBoxStrong.Text), textBoxColor.Text, comboBox1.Text);
                    DataGridViewRow row = new DataGridViewRow();
                    DataGridViewTextBoxCell cell1 = new DataGridViewTextBoxCell();
                    DataGridViewTextBoxCell cell2 = new DataGridViewTextBoxCell();
                    DataGridViewTextBoxCell cell3 = new DataGridViewTextBoxCell();
                    DataGridViewTextBoxCell cell4 = new DataGridViewTextBoxCell();
                    DataGridViewTextBoxCell cell5 = new DataGridViewTextBoxCell();
                    DataGridViewTextBoxCell cell6 = new DataGridViewTextBoxCell();
                    try
                    {
                        dev.Set_price(comboBoxModel.SelectedIndex, comboBoxStrong.SelectedIndex);
                        Dev.Add(dev);
                        Devices.Add(dev.Enter_name(), dev);
                        cell1.Value = dev.Enter_device();
                        cell2.Value = dev.Enter_name();
                        cell3.Value = dev.Enter_model();
                        cell4.Value = dev.Enter_W();
                        cell5.Value = dev.Enter_color();
                        cell6.Value = dev.Enter_price();
                        row.Cells.Add(cell1);
                        row.Cells.Add(cell2);
                        row.Cells.Add(cell3);
                        row.Cells.Add(cell4);
                        row.Cells.Add(cell5);
                        row.Cells.Add(cell6);
                        dataGridView1.Rows.Add(row);
                    }
                    catch
                    {
                        MessageBox.Show("Элемент с таким названием уже присутствует");
                    }
                }
                catch {; }
                
            }
    }

        private void comboBoxType_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
